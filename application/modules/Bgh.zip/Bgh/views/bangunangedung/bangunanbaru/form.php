<!-- Page header -->
<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="row g-2 align-items-center">
            <div class="col">
                <h2 class="page-title">
                    Permohonan BGH
                </h2>
            </div>
        </div>
    </div>
</div>
<!-- Page body -->
<div class="page-body">
  <div class="container-xl">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Tahap Perencanaan</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-stripped">
                            <thead>
                                <th>Nama</th>
                                <th>Kode</th>
                                <th>Poin</th>
                                <th>Claim Poin</th>
                                <th>Dokumen Pembuktian</th>
                                <th>Estimasi Poin</th>
                                <th>Assesment Poin</th>
                                <th>Catatan</th>
                                <th>Verifikasi</th>
                            </thead>
                            <tbody>
                                <?php  
                                    // print_r($checklist);
                                    for($i=0; $i<count($checklist); $i++){
                                ?>
                                <tr>
                                    <td><strong><?= $checklist[$i]['nama'] ?></strong></td>
                                    <td><?= $checklist[$i]['kode'] ?></td>
                                    <td><?= $checklist[$i]['poin'] ?></td>
                                    <td></td>
                                    <td></td>
                                    <td>0</td>
                                    <td>0</td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php for($j=0; $j<count($checklist[$i]['main']); $j++) { ?>
                                    <tr>
                                        <td class="ps-5"><strong><?= ($j+1).". ".$checklist[$i]['main'][$j]['nama'] ?></strong></td>
                                        <td><?= $checklist[$i]['main'][$j]['kode'] ?></td>    
                                        <td><?= $checklist[$i]['main'][$j]['poin'] ?></td>    
                                        <td></td>
                                        <td></td>
                                        <td>0</td>
                                        <td>0</td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <?php 
                                    for($k=0; $k<count($checklist[$i]['main'][$j]['sub']); $k++) { 
                                        if($checklist[$i]['main'][$j]['sub'][$k]['dokumen'] == 1){
                                    ?>
                                        <tr>
                                            <td class="ps-6"><?= ($k+1).' '.$checklist[$i]['main'][$j]['sub'][$k]['nama'] ?></td>
                                            <td><?= $checklist[$i]['main'][$j]['sub'][$k]['kode'] ?></td>    
                                            <td><?= $checklist[$i]['main'][$j]['sub'][$k]['poin'] ?></td>
                                            <td>
                                                <select name="" id="" class="form-control">
                                                    <option value="0">TIDAK</option>
                                                    <option value="1">AMBIL</option>
                                                </select>
                                            </td>
                                            <td>
                                                <table class="table table-stripped">
                                                <?php for($o=0; $o<count($checklist[$i]['main'][$j]['sub'][$k]['dok']); $o++) { ?>
                                                        <tr>
                                                            <td><?= $checklist[$i]['main'][$j]['sub'][$k]['dok'][$o]['nama']?></td>
                                                            <td>
                                                                <input type="file">
                                                            </td>
                                                        </tr>
                                                <?php } ?>
                                                </table>
                                            </td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                    <?php }else{ ?> 
                                        
                                        <tr>
                                            <td class="ps-6"><?= $checklist[$i]['main'][$j]['sub'][$k]['nama'] ?></td>
                                            <td><?= $checklist[$i]['main'][$j]['sub'][$k]['kode'] ?></td>    
                                            <td><?= $checklist[$i]['main'][$j]['sub'][$k]['poin'] ?></td>  
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <?php for($l=0; $l<count($checklist[$i]['main'][$j]['sub'][$k]['subsub']); $l++) { ?>
                                            
                                            <tr>
                                                <td class="ps-7"><?= ($l+1).". ".$checklist[$i]['main'][$j]['sub'][$k]['subsub'][$l]['nama'] ?></td>
                                                <td ><?= $checklist[$i]['main'][$j]['sub'][$k]['subsub'][$l]['kode'] ?></td>
                                                <td ><?= $checklist[$i]['main'][$j]['sub'][$k]['subsub'][$l]['poin'] ?></td>
                                                <td >
                                                    <select name="" id="" class="form-control">
                                                        <option value="0">TIDAK</option>
                                                        <option value="1">AMBIL</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <table class="table table-stripped">
                                                    <?php for($o=0; $o<count($checklist[$i]['main'][$j]['sub'][$k]['subsub'][$l]['dok']); $o++) { ?>
                                                        <tr>
                                                            <td>
                                                                <?= $checklist[$i]['main'][$j]['sub'][$k]['subsub'][$l]['dok'][$o]['nama'] ?>
                                                            </td>
                                                            <td>
                                                                <input type="file">
                                                            </td>
                                                        </tr>
                                                        <?php } ?>
                                                    </table>
                                                </td>
                                                <td>0</td>
                                                <td></td>
                                                <td></td>
                                                <td></td>

                                            </tr>
                                        <?php } ?>
                                        <?php } ?>
                                    <?php } ?>
                                <?php } ?>
                                
                                <?php } ?>
                            </tbody>

                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</div>

<script src="<?= base_url() ?>assets/bgh/dist/libs/jQuery-3.6.0/jquery-3.6.0.min.js"></script>
<script src="<?= base_url() ?>assets/bgh/dist/libs/DataTables-1.13.4/js/datatables.min.js"></script>

<script>
    $(() => {
        $('#menu-bangunan').addClass('active');
    })
</script>